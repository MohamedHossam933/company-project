
package company.project;

import forms.*;

public class CompanyProject {

    public static void main(String[] args) {
        // TODO code application logic here
        login log = new login();
        log.setTitle("Login");
        Tools.open(log);
        //Tools.open(new employee());
        //Tools.open(new projects());
        //Tools.open(new test());
        //Tools.open(new work_on());
        //Tools.open(new mainReports());
    }
    
}
